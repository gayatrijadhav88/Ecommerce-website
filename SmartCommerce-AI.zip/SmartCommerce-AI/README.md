# SmartCommerce AI

AI-Powered E-Commerce Platform with Personalized Recommendations, Semantic Search, and AI Shopping Assistant.

## Tech Stack

- Frontend: React.js, JavaScript, Redux Toolkit, React Router DOM, Axios, Tailwind CSS, Recharts
- Backend: Node.js, Express.js, MongoDB Atlas, Mongoose, JWT, RBAC
- AI Services: Python, FastAPI, Scikit-Learn, Sentence Transformers, FAISS, LangChain, Gemini API

## Folder Structure

```text
SmartCommerce-AI/
  client/
  server/
  ai-services/
    recommendation-engine/
    semantic-search/
    chatbot-service/
  docs/
```

## Quick Start

1. Install Node dependencies:

```bash
npm install
npm run install:all
```

2. Configure backend:

```bash
cp server/.env.example server/.env
```

3. Configure AI services:

```bash
cp ai-services/recommendation-engine/.env.example ai-services/recommendation-engine/.env
cp ai-services/semantic-search/.env.example ai-services/semantic-search/.env
cp ai-services/chatbot-service/.env.example ai-services/chatbot-service/.env
```

4. Seed products and admin user:

```bash
npm run seed --prefix server
```

5. Run backend and frontend:

```bash
npm run dev
```

6. Run AI services in separate terminals:

```bash
cd ai-services/recommendation-engine && pip install -r requirements.txt && uvicorn main:app --reload --port 8001
cd ai-services/semantic-search && pip install -r requirements.txt && uvicorn main:app --reload --port 8002
cd ai-services/chatbot-service && pip install -r requirements.txt && uvicorn main:app --reload --port 8003
```

## Default Seed Login

- Admin: `admin@smartcommerce.ai` / `Admin@123`
- Customer: `customer@smartcommerce.ai` / `Customer@123`

## Main APIs

- Auth: `/api/auth/register`, `/api/auth/login`, `/api/auth/me`
- Products: `/api/products`, `/api/products/:id`, `/api/products/:id/similar`
- Cart: `/api/cart`
- Wishlist: `/api/wishlist`
- Orders: `/api/orders`
- Admin: `/api/admin/products`, `/api/admin/analytics`
- AI: `/api/ai/recommendations`, `/api/ai/search`, `/api/ai/chat`

## Deployment

- Frontend: Vercel, root `client`, build `npm run build`
- Backend: Render Web Service, root `server`, start `npm start`
- Database: MongoDB Atlas
- AI Services: Render Web Services, one service per FastAPI app

Complete guides and final-year-project documentation are in [docs](docs/).

